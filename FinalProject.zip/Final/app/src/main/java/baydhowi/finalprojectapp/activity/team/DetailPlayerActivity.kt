package baydhowi.finalprojectapp.activity.team

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.MenuItem
import android.widget.ImageView
import android.widget.TextView
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.model.data.PlayerData
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_detail_player.*

class DetailPlayerActivity : AppCompatActivity() {

    private lateinit var playerData: PlayerData
    lateinit var player_banner: ImageView
    lateinit var player_name_position: TextView
    lateinit var player_weight: TextView
    lateinit var player_height: TextView
    lateinit var player_desc: TextView

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        super.onBackPressed()
        return super.onOptionsItemSelected(item)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_player)

        // initialize objects
        initObjects()

        // initialize intent
        initIntent()

        // initialize data from intent
        setDataToObjects()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = playerData.mNamePlayer + " Profile"
    }

    private fun initObjects() {
        player_banner = player_banner_id
        player_name_position = player_name_position_id
        player_weight = player_weight_id
        player_height = player_height_id
        player_desc = player_description_id
    }

    private fun initIntent() {
        val intent = intent
        playerData = intent.getParcelableExtra("player_data")
    }

    private fun setDataToObjects() {
        if(playerData.mFanArt1.isNullOrEmpty()){
            Glide.with(this).load(R.drawable.soccer_field).into(player_banner)
        } else {
            Glide.with(this).load(playerData.mFanArt1).into(player_banner)
        }

        player_name_position.text = playerData.mNamePlayer + " as " + playerData.mPosition

        if(playerData.mWeight.isNullOrEmpty()) {
            player_weight.setText(" - ")
        } else {
            player_weight.text = playerData.mWeight
        }

        if(playerData.mHeight.isNullOrEmpty()){
            player_height.setText(" - ")
        } else {
            player_height.text = playerData.mHeight
        }

        player_desc.text = playerData.mDescriptionEN
    }
}
