package baydhowi.finalprojectapp.model.response

import baydhowi.finalprojectapp.model.data.TeamData

data class TeamResponse(val teams: List<TeamData>)