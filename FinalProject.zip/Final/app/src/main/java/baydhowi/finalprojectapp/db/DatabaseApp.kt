package baydhowi.finalprojectapp.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import baydhowi.finalprojectapp.db.table.MatchTable
import baydhowi.finalprojectapp.db.table.TeamTable
import org.jetbrains.anko.db.*

class DatabaseApp(ctx: Context)
    : ManagedSQLiteOpenHelper(ctx, "FootballApps.db",null,1)
{

    companion object {
        private var instance: DatabaseApp? = null

        @Synchronized
        fun getInstance(ctx: Context): DatabaseApp {
            if (instance == null) {
                instance = DatabaseApp(ctx.applicationContext)
            }
            return instance as DatabaseApp
        }
    }

    override fun onCreate(db: SQLiteDatabase?) {
        if (db != null) {
            db.createTable(MatchTable.table_name,true,
                MatchTable.ID to INTEGER + PRIMARY_KEY + AUTOINCREMENT,
                MatchTable.id_event to TEXT + UNIQUE,
                MatchTable.date_event to TEXT,
                MatchTable.home_team to TEXT,
                MatchTable.away_team to TEXT,
                MatchTable.home_score to TEXT,
                MatchTable.away_score to TEXT,
                MatchTable.home_goal_detail to TEXT,
                MatchTable.away_goal_detail to TEXT,
                MatchTable.match_time to TEXT
            )

            db.createTable(TeamTable.table_name, true,
                TeamTable.ID to INTEGER + PRIMARY_KEY + AUTOINCREMENT,
                TeamTable.id_team to TEXT + UNIQUE,
                TeamTable.team_name to TEXT,
                TeamTable.team_image to TEXT,
                TeamTable.team_year to TEXT,
                TeamTable.team_stadium to TEXT,
                TeamTable.thumb_stadium to TEXT,
                TeamTable.team_fanart_1 to TEXT,
                TeamTable.team_fanart_2 to TEXT,
                TeamTable.team_desc to TEXT
            )
        }
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        if (db != null) {
            db.dropTable(MatchTable.table_name, true)
            db.dropTable(TeamTable.table_name, true)
        }
    }

}

val Context.dbApp: DatabaseApp
    get() = DatabaseApp.getInstance(applicationContext)