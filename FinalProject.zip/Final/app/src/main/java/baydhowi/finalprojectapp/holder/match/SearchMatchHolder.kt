package baydhowi.finalprojectapp.holder.match

import android.content.Intent
import android.provider.CalendarContract
import android.support.v7.widget.RecyclerView
import android.view.View
import android.widget.TextView
import baydhowi.finalprojectapp.model.data.SearchMatchData
import baydhowi.finalprojectapp.utils.convertToGMT
import baydhowi.finalprojectapp.utils.validateNullTime
import kotlinx.android.synthetic.main.match_data.view.*
import java.text.SimpleDateFormat

class SearchMatchHolder(v: View): RecyclerView.ViewHolder(v) {

    val date_event: TextView = v.date_id
    val match_time: TextView = v.match_time_id
    val home_team: TextView = v.home_team_id
    val away_team: TextView = v.away_team_id
    val home_score: TextView = v.home_score_id
    val away_score: TextView = v.away_score_id

    fun bindItem(item: SearchMatchData, listener: (SearchMatchData) -> Unit){
        val dateConvert = convertToGMT(item.mDateEvent, validateNullTime(item.mTime))
        val newDate = SimpleDateFormat("E, d MMM yyyy")
        val newTime = SimpleDateFormat("HH:mm")
        val date = newDate.format(dateConvert)
        val time = newTime.format(dateConvert)

        date_event.text = "$date"
        match_time.text = "$time"
        home_team.text = item.mHomeTeam
        away_team.text = item.mAwayTeam
        home_score.text = item.mHomeScore
        away_score.text = item.mAwayScore

        itemView.setOnClickListener {
            listener(item)
        }

        setEventOnAlarm(itemView, item)
    }

    private fun setEventOnAlarm(v: View, data: SearchMatchData) {
        v.alarm_id.setOnClickListener {
            val intent = Intent(Intent.ACTION_EDIT)
            intent.type = "vnd.android.cursor.item/event"
            intent.putExtra(CalendarContract.Events.TITLE, data.mHomeTeam + " vs " + data.mAwayTeam)
            intent.putExtra(CalendarContract.Events.DESCRIPTION, data.mHomeTeam + " vs " + data.mAwayTeam)
            intent.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, data.mDateEvent)
            intent.putExtra(CalendarContract.Events.ALL_DAY, false)
            itemView.context.startActivity(intent)
        }
    }

}