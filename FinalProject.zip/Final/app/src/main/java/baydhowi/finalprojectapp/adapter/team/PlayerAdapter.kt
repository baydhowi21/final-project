package baydhowi.finalprojectapp.adapter.team

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.holder.team.PlayerHolder
import baydhowi.finalprojectapp.model.data.PlayerData

class PlayerAdapter(private val data: List<PlayerData>,
                    private val event: (PlayerData) -> Unit)
    : RecyclerView.Adapter<PlayerHolder>()
{
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlayerHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.player_data, parent, false)
        return PlayerHolder(v)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: PlayerHolder, position: Int) {
        holder.bindItem(data[position], event)
    }
}