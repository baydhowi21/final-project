package baydhowi.finalprojectapp.activity.team

import android.database.sqlite.SQLiteConstraintException
import android.os.Bundle
import android.support.design.widget.CoordinatorLayout
import android.support.design.widget.Snackbar
import android.support.v4.app.FragmentTransaction
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageView
import android.widget.TextView
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.db.dbApp
import baydhowi.finalprojectapp.db.table.TeamTable
import baydhowi.finalprojectapp.fragment.team.DetailTeamFragment
import baydhowi.finalprojectapp.model.data.TeamData
import baydhowi.finalprojectapp.utils.setMenu
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_detail_team.*
import org.jetbrains.anko.db.classParser
import org.jetbrains.anko.db.delete
import org.jetbrains.anko.db.insert
import org.jetbrains.anko.db.select

class DetailTeamActivity : AppCompatActivity() {

    private var menuItem: Menu? = null
    private var isActive: Boolean = false
    private lateinit var teamData: TeamData
    lateinit var background_image: ImageView
    lateinit var team_image: ImageView
    lateinit var team_name: TextView
    lateinit var team_year: TextView
    lateinit var team_stadium: TextView
    lateinit var main_view: CoordinatorLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_team)

        // initialize objects
        initObjects()

        // initialize intent
        initIntent()

        // initialize data from intent
        setDataToObjects()

        // initialize default icon favorite
        initDefaultFav()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = teamData.mTeamName

        this.setFragmentToContainer("overview")
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.fav_menu, menu)
        menuItem = menu
        setMenu(this, isActive, menuItem)

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item != null) {
            return when (item.itemId) {
                android.R.id.home -> {
                    super.onBackPressed()
                    true
                }
                R.id.add_to_favorite_id -> {
                    if (isActive) {
                        remFav()
                    } else {
                        addFav()
                    }
                    isActive = !isActive
                    setMenu(this, isActive, menuItem)
                    true
                }
                else -> super.onOptionsItemSelected(item)
            }
        } else {
            return super.onOptionsItemSelected(item)
        }
    }

    private fun initObjects() {
        team_image = team_detail_image_id
        team_name = team_detail_name_id
        background_image = team_detail_background_id
        team_year = team_detail_year_id
        team_stadium = team_detail_stadium_id
        main_view = main_view_detail_team_id
    }

    private fun setDataToObjects() {
        Glide.with(this).load(teamData.mTeamBadge).into(team_image)
        team_name.text = teamData.mTeamName
        team_year.text = teamData.mTeamFormedYear
        team_stadium.text = teamData.mTeamStadium

        if (teamData.mStadiumThumb.isNullOrEmpty()){
            Glide.with(this).load(R.drawable.soccer_field).into(background_image)
        } else {
            Glide.with(this).load(teamData.mStadiumThumb).into(background_image)
        }
    }

    private fun initIntent() {
        val intent = intent
        teamData = intent.getParcelableExtra("team_data")
    }

    private fun initDefaultFav(){
        try {
            dbApp.use {
                val result = select(TeamTable.table_name).whereArgs("( id_team = {id_team})",
                    "id_team" to teamData.mIdTeam.toString())
                val favoriteTeam = result.parseList(classParser<TeamTable>())
                if (!favoriteTeam.isEmpty()) isActive = true
            }
        } catch (e: SQLiteConstraintException){
            Log.d("BTW - DEF", e.localizedMessage)
        }
    }

    private fun addFav() {
        try {
            dbApp.use {
                insert(TeamTable.table_name,
                    TeamTable.id_team to teamData.mIdTeam,
                    TeamTable.team_name to teamData.mTeamName,
                    TeamTable.team_image to teamData.mTeamBadge,
                    TeamTable.team_year to teamData.mTeamFormedYear,
                    TeamTable.team_stadium to teamData.mTeamStadium,
                    TeamTable.thumb_stadium to teamData.mStadiumThumb,
                    TeamTable.team_fanart_1 to teamData.mTeamFanArt1,
                    TeamTable.team_fanart_2 to teamData.mTeamFanArt2,
                    TeamTable.team_desc to teamData.mTeamDescription)
            }
            Snackbar.make(main_view,
                "Data " + teamData.mTeamName + " telah ditambahkan ke favorit",
                Snackbar.LENGTH_SHORT).show()
        } catch (e: SQLiteConstraintException){
            Log.d("BTW - ADD", e.localizedMessage)
        }
    }

    private fun remFav() {
        try {
            dbApp.use {
                delete(TeamTable.table_name, "( id_team = {id_team} )",
                    "id_team" to teamData.mIdTeam.toString())
            }
            Snackbar.make(main_view,
                "Data " + teamData.mTeamName + " telah dihapus dari favorit",
                Snackbar.LENGTH_SHORT).show()
        } catch (e: SQLiteConstraintException){
            Log.d("BTW - REM", e.localizedMessage)
        }
    }

    fun setFragmentToContainer(fragmentName: String) {
        var ft: FragmentTransaction = supportFragmentManager.beginTransaction()
        when (fragmentName) {
            "overview" -> ft.replace(R.id.fragment_container, DetailTeamFragment())
        }
        ft.commit()
    }
}
