package baydhowi.finalprojectapp.adapter.team

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.holder.team.SearchTeamHolder
import baydhowi.finalprojectapp.model.data.TeamData
import baydhowi.finalprojectapp.presenter.team.SearchTeamPresenter

class SearchTeamAdapter(private val data: List<TeamData>,
                        private val event: (TeamData) -> Unit)
    : RecyclerView.Adapter<SearchTeamHolder>()
{
    private lateinit var presenter          : SearchTeamPresenter

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SearchTeamHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.team_data, parent, false)
        return SearchTeamHolder(v)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: SearchTeamHolder, position: Int) {
        holder.bindItem(data[position], event)
    }
}