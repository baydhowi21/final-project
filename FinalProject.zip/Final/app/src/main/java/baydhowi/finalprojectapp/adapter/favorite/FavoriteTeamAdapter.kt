package baydhowi.finalprojectapp.adapter.favorite

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.holder.favorite.FavoriteTeamHolder
import baydhowi.finalprojectapp.model.data.TeamData

class FavoriteTeamAdapter(private val data: MutableList<TeamData>,
                          private val event: (TeamData) -> Unit)
    : RecyclerView.Adapter<FavoriteTeamHolder>()
{
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteTeamHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.team_data, parent, false)
        return FavoriteTeamHolder(v)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: FavoriteTeamHolder, position: Int) {
        holder.bindItem(data[position], event)
    }
}