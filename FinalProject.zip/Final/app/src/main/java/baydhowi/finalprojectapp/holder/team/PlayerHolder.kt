package baydhowi.finalprojectapp.holder.team

import android.support.v7.widget.RecyclerView
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.model.data.PlayerData
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.player_data.view.*

class PlayerHolder(v: View): RecyclerView.ViewHolder(v) {

    val player_image: ImageView = v.player_image_id
    val player_name: TextView = v.player_name_id
    val player_position: TextView = v.player_position_id

    fun bindItem (item: PlayerData, listener: (PlayerData) -> Unit) {
        player_name.text = item.mNamePlayer
        player_position.text = item.mPosition
        if(item.mCutOut.isNullOrEmpty()) {
            Glide.with(itemView.context).load(R.drawable.ic_default_logo_24dp).into(player_image)
        } else {
            Glide.with(itemView.context).load(item.mCutOut).into(player_image)
        }

        itemView.setOnClickListener {
            listener(item)
        }
    }

}