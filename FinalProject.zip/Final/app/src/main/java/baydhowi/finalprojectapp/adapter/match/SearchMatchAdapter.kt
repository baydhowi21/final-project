package baydhowi.finalprojectapp.adapter.match

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.holder.match.SearchMatchHolder
import baydhowi.finalprojectapp.model.data.SearchMatchData
import baydhowi.finalprojectapp.presenter.match.SearchMatchPresenter

class SearchMatchAdapter(private val data: MutableList<SearchMatchData>,
                         private val event: (SearchMatchData) -> Unit)
    : RecyclerView.Adapter<SearchMatchHolder>()
{
    private lateinit var presenter          : SearchMatchPresenter

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SearchMatchHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.match_data, parent, false)
        return SearchMatchHolder(v)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: SearchMatchHolder, position: Int) {
        holder.bindItem(data[position], event)
    }
}