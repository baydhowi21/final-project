package baydhowi.finalprojectapp.activity.team

import android.os.Bundle
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.widget.ProgressBar
import android.widget.SearchView
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.adapter.team.SearchTeamAdapter
import baydhowi.finalprojectapp.model.data.TeamData
import baydhowi.finalprojectapp.presenter.team.SearchTeamPresenter
import baydhowi.finalprojectapp.utils.apiReq
import baydhowi.finalprojectapp.utils.gsonReq
import baydhowi.finalprojectapp.utils.invisible
import baydhowi.finalprojectapp.utils.visible
import baydhowi.finalprojectapp.view.team.SearchTeamView
import kotlinx.android.synthetic.main.activity_search_team.*
import org.jetbrains.anko.sdk27.coroutines.onQueryTextListener
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.support.v4.onRefresh

class SearchTeamActivity : AppCompatActivity(), SearchTeamView {

    private lateinit var swipeRefresh       : SwipeRefreshLayout
    private lateinit var progressBar        : ProgressBar
    lateinit var searchView                 : SearchView
    private lateinit var recyclerView       : RecyclerView
    lateinit var presenter                  : SearchTeamPresenter
    private var dataParms                   : MutableList<TeamData> = mutableListOf()
    private var dataItems                   : MutableList<TeamData> = mutableListOf()
    lateinit var adapter                    : SearchTeamAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_team)

        // hide action bar
        supportActionBar?.hide()

        // initialize object from layout
        initObjects()

        // initialize object event
        initListener()

        // initialize adapter
        initAdapter()

        // initialize default data
        initDefaultData()

        // initialize swipe refresh
        setRefreshEvent()
    }

    override fun showDlg() {
        progressBar.visible()
    }

    override fun hideDlg() {
        progressBar.invisible()
    }

    override fun showData(data: List<TeamData>) {
        dataItems.clear()
        dataItems.addAll(data)
        adapter.notifyDataSetChanged()
        hideDlg()
    }

    private fun initObjects() {
        swipeRefresh = swipe_search_team_id
        progressBar = search_team_progress_id
        searchView = search_view_team_id
        recyclerView = search_team_rv_id

        presenter = SearchTeamPresenter(this, apiReq(), gsonReq())
    }

    private fun initAdapter() {
        adapter = SearchTeamAdapter(dataItems) {
            setDataList(it)
            goToDetailMatch()
        }
        setDataToRecyclerView()
    }

    private fun setDataList(data: TeamData) {
        dataParms.clear()
        dataParms.add(
            TeamData(0,
                data.mIdTeam,
                data.mTeamName,
                data.mTeamBadge,
                data.mTeamFormedYear,
                data.mTeamStadium,
                data.mStadiumThumb,
                data.mTeamFanArt1,
                data.mTeamFanArt2,
                data.mTeamDescription))
    }

    private fun setDataToRecyclerView() {
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun goToDetailMatch() {
        this.startActivity<DetailTeamActivity>("team_data" to dataParms[0])
    }

    private fun initListener() {
        searchView.onActionViewExpanded()
        searchView.onQueryTextListener() {
            onQueryTextChange { it ->
                presenter.getData(it, "team", "t")
                true
            }
            hideDlg()
        }
    }

    private fun initDefaultData() {
        var team: String = ""
        presenter.getData(team, "team", "t")
        hideDlg()
    }

    private fun setRefreshEvent() {
        swipeRefresh.onRefresh {
            initDefaultData()
        }
    }
}
