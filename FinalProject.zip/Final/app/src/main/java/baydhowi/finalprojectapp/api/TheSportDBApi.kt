package baydhowi.finalprojectapp.api

import android.net.Uri
import baydhowi.finalprojectapp.BuildConfig

object TheSportDBApi {

    // mendapatkan halaman yang diproses
    fun getProcessType(type: String?) : String? {
        var pageProcess: String? = ""
        when (type) {
            "prev" -> pageProcess = "eventspastleague.php"
            "next" -> pageProcess = "eventsnextleague.php"
            "detail" -> pageProcess = "lookupevent.php"
            "badge" -> pageProcess = "searchteams.php"
            "team" -> pageProcess = "searchteams.php"
            "all_teams" -> pageProcess = "search_all_teams.php"
            "lookup_team" -> pageProcess = "lookupteam.php"
            "lookup_all_players" -> pageProcess = "lookup_all_players.php"
            "event" -> pageProcess = "searchevents.php"
        }

        return pageProcess
    }

    // mendapatkan parameter yang akan diproses
    fun getActionType(action: String?) : String? {
        var actionType: String? = ""
        when (action) {
            "id" -> actionType = "id"
            "t" -> actionType = "t"
            "l" -> actionType = "l"
            "e" -> actionType = "e"
        }

        return actionType
    }

    // base pattern yang akan digunakan
    fun getDataFromURL(id: String?, type: String?, action: String?): String {
        var pageProcess: String? = getProcessType(type)
        var actionType: String? = getActionType(action)

        return Uri.parse(BuildConfig.BASE_URL).buildUpon()
                .appendPath("api")
                .appendPath("v1")
                .appendPath("json")
                .appendPath(BuildConfig.API_KEY)
                .appendPath(pageProcess)
                .appendQueryParameter(actionType, id)
                .build()
                .toString()
    }
}