package baydhowi.finalprojectapp.adapter

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter

class PageAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm) {

    private val frag_list: MutableList<Fragment> = mutableListOf()
    private val frag_list_title: MutableList<String> = mutableListOf()

    override fun getItem(position: Int): Fragment {
        return frag_list.get(position)
    }

    override fun getCount(): Int {
        return frag_list.size
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return frag_list_title.get(position)
    }

    fun addFragment(fragment: Fragment?, title: String?) {
        if (fragment != null) {
            frag_list.add(fragment)
        }
        if (title != null) {
            frag_list_title.add(title)
        }
    }
}