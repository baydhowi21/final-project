package baydhowi.finalprojectapp.db.table

data class TeamTable(val id: Long?,
                     val id_team: String?,
                     val team_name: String?,
                     val team_image: String?,
                     val team_year: String?,
                     val team_stadium: String?,
                     val thumb_stadium: String?,
                     val team_fanart_1: String?,
                     val team_fanart_2: String?,
                     val team_desc: String?)
{

    companion object {
        const val table_name: String = "favorite_team"
        const val ID: String = "ID_"
        const val id_team: String = "id_team"
        const val team_name: String = "team_name"
        const val team_image: String = "team_image"
        const val team_year: String = "team_year"
        const val team_stadium: String = "team_stadium"
        const val thumb_stadium: String = "thumb_stadium"
        const val team_fanart_1: String = "team_fanart_1"
        const val team_fanart_2: String = "team_fanart_2"
        const val team_desc: String = "team_desc"
    }

}