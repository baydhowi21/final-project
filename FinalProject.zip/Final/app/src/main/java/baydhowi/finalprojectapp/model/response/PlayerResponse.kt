package baydhowi.finalprojectapp.model.response

import baydhowi.finalprojectapp.model.data.PlayerData

data class PlayerResponse(val player: List<PlayerData>)