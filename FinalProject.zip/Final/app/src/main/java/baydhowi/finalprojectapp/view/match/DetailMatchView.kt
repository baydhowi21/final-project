package baydhowi.finalprojectapp.view.match

import baydhowi.finalprojectapp.model.data.BadgeData
import baydhowi.finalprojectapp.model.data.DetailMatchData

interface DetailMatchView {

    fun showDlg()
    fun hideDlg()
    fun showData(data: List<DetailMatchData>)
    fun showHomeTeamBadge(data: List<BadgeData>)
    fun showAwayTeamBadge(data: List<BadgeData>)

}