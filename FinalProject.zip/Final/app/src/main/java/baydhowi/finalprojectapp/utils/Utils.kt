package baydhowi.finalprojectapp.utils

import android.content.Context
import android.support.v4.content.ContextCompat
import android.view.Menu
import android.view.View
import android.widget.Spinner
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.api.ApiRequest
import baydhowi.finalprojectapp.presenter.match.MatchPresenter
import com.google.gson.Gson
import java.text.SimpleDateFormat
import java.util.*

// menampilkan progress bar
fun View.visible() {
    visibility = View.VISIBLE
}

// menyembunyikan progress bar
fun View.invisible() {
    visibility = View.INVISIBLE
}

// split data
fun splitData(data: String?): List<String> {
    return data.toString().split(";")
}

// convert format tanggal
fun convertTgl(tgl: String?) : String {
    val fmt = SimpleDateFormat("yyyy-MM-dd")
    val date = fmt.parse(tgl)
    val fmtOut = SimpleDateFormat("d MMM yyyy")

    return fmtOut.format(date).toString();
}

fun validateNullTime(time: String?) : String {
    val newTime: String?
    if (time == null) {
        newTime = "00:00:00"
    } else if (time == "null") {
        newTime = "00:00:00"
    } else if (time == "") {
        newTime = "00:00:00"
    } else {
        newTime = time
    }

    return newTime
}

// format GMT
fun convertToGMT(date: String?, time: String?): Date? {
    val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    formatter.timeZone = TimeZone.getTimeZone("UTC")
    val dateTime = "$date $time"

    return formatter.parse(dateTime)
}

// api request
fun apiReq() : ApiRequest {
    return ApiRequest()
}

// gson
fun gsonReq() : Gson {
    return Gson()
}

// menu
fun setMenu(ctx: Context, isActive: Boolean, menu: Menu?) {
    if (isActive) {
        menu?.getItem(0)?.icon = ContextCompat.getDrawable(ctx, R.drawable.ic_add_favorite_black_24dp)
    } else {
        menu?.getItem(0)?.icon = ContextCompat.getDrawable(ctx, R.drawable.ic_add_favorite_24dp)
    }
}

// match
fun setMatch(matchType: String, position: Int, spinner: Spinner, presenter: MatchPresenter) : String {
    var leagueLoc: String = ""
    when (position) {
        0 -> {
            leagueLoc = spinner.selectedItem.toString().replace("Spanish La Liga", "4335")
            presenter.getData(leagueLoc, matchType, "id")
        }
        1 -> {
            leagueLoc = spinner.selectedItem.toString().replace("English Premier League", "4328")
            presenter.getData(leagueLoc, matchType, "id")
        }
        2 -> {
            leagueLoc = spinner.selectedItem.toString().replace("English League Championship", "4329")
            presenter.getData(leagueLoc, matchType, "id")
        }
        3 -> {
            leagueLoc = spinner.selectedItem.toString().replace("German Bundesliga", "4331")
            presenter.getData(leagueLoc, matchType, "id")
        }
        4 -> {
            leagueLoc = spinner.selectedItem.toString().replace("Italian Serie A", "4332")
            presenter.getData(leagueLoc, matchType, "id")
        }
        5 -> {
            leagueLoc = spinner.selectedItem.toString().replace("French Ligue 1", "4334")
            presenter.getData(leagueLoc, matchType, "id")
        }
    }

    return leagueLoc
}