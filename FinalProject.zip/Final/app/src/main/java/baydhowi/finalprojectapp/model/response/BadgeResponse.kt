package baydhowi.finalprojectapp.model.response

import baydhowi.finalprojectapp.model.data.BadgeData

data class BadgeResponse(val teams: List<BadgeData>)