package baydhowi.finalprojectapp.db.table

data class MatchTable(val id: Long?,
                         val id_event: String?,
                         val date_event: String?,
                         val home_team: String?,
                         val away_team: String?,
                         val home_score: String?,
                         val away_score: String?,
                         val home_goal_detail: String?,
                         val away_goal_detail: String?,
                         val match_time: String?)
{

    companion object {
        const val table_name: String = "favorite_match"
        const val ID: String = "ID_"
        const val id_event = "id_event"
        const val date_event = "date_event"
        const val home_team = "home_team"
        const val away_team = "away_team"
        const val home_score = "home_score"
        const val away_score = "away_score"
        const val home_goal_detail = "home_goal_detail"
        const val away_goal_detail = "away_goal_detail"
        const val match_time = "match_time"
    }

}