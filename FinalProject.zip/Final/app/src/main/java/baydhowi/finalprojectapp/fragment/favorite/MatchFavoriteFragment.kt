package baydhowi.finalprojectapp.fragment.favorite


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.activity.match.DetailMatchActivity
import baydhowi.finalprojectapp.adapter.favorite.FavoriteMatchAdapter
import baydhowi.finalprojectapp.db.dbApp
import baydhowi.finalprojectapp.db.table.MatchTable
import baydhowi.finalprojectapp.model.data.MatchData
import kotlinx.android.synthetic.main.fragment_match_favorite.*
import org.jetbrains.anko.db.classParser
import org.jetbrains.anko.db.select
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.support.v4.ctx
import org.jetbrains.anko.support.v4.onRefresh

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 *
 */
class MatchFavoriteFragment : Fragment() {

    private var favoriteMatch : MutableList<MatchTable> = mutableListOf()
    private lateinit var adapter: FavoriteMatchAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    lateinit var matchData: MatchData

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        // initialize objects
        initObjects()

        // initialize recycler view
        initRecyclerView()

        // initialize swipe refresh
        initRefreshData()

        // initialize data from sql lite
        showData()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_match_favorite, container, false)
    }

    private fun initRecyclerView() {
        adapter = FavoriteMatchAdapter(favoriteMatch) {
            context?.startActivity<DetailMatchActivity>("id_event" to "${it.id_event}",
                "home_team" to "${it.home_team}",
                "home_score" to "${it.home_score}",
                "away_team" to "${it.away_team}",
                "away_score" to "${it.away_score}",
                "date_event" to "${it.date_event}",
                "match_time" to "${it.match_time}")
        }

        recyclerView.layoutManager = LinearLayoutManager(ctx)
        recyclerView.adapter = adapter
    }

    private fun initObjects() {
        swipeRefresh = fav_match_swipe_refresh_id
        recyclerView = fav_match_rv_id
    }

    private fun showData() {
        context?.dbApp?.use {
            swipeRefresh.isRefreshing = false
            val result = select(MatchTable.table_name)
            val favorite = result.parseList(classParser<MatchTable>())
            favoriteMatch.addAll(favorite)
            adapter.notifyDataSetChanged()
        }
    }

    private fun initRefreshData() {
        swipeRefresh.onRefresh {
            favoriteMatch.clear()
            showData()
        }
    }
}
