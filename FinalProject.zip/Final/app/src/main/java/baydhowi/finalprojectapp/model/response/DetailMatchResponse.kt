package baydhowi.finalprojectapp.model.response

import baydhowi.finalprojectapp.model.data.DetailMatchData

data class DetailMatchResponse (val events: List<DetailMatchData>)