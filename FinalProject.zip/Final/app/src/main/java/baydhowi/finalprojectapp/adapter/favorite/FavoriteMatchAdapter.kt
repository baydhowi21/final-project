package baydhowi.finalprojectapp.adapter.favorite

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.db.table.MatchTable
import baydhowi.finalprojectapp.holder.favorite.FavoriteMatchHolder
import baydhowi.finalprojectapp.presenter.match.MatchPresenter

class FavoriteMatchAdapter(private val data: MutableList<MatchTable>,
                           private val event: (MatchTable) -> Unit)
    : RecyclerView.Adapter<FavoriteMatchHolder>()
{
    private lateinit var presenter          : MatchPresenter

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteMatchHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.match_data, parent, false)
        return FavoriteMatchHolder(v)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: FavoriteMatchHolder, position: Int) {
        holder.bindItem(data[position], event)
    }
}