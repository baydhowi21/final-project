package baydhowi.finalprojectapp.model.response

import baydhowi.finalprojectapp.model.data.SearchMatchData

data class SearchMatchResponse (val event: List<SearchMatchData>)