package baydhowi.finalprojectapp.activity.match

import android.os.Bundle
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.widget.ProgressBar
import android.widget.SearchView
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.adapter.match.SearchMatchAdapter
import baydhowi.finalprojectapp.model.data.MatchData
import baydhowi.finalprojectapp.model.data.SearchMatchData
import baydhowi.finalprojectapp.presenter.match.SearchMatchPresenter
import baydhowi.finalprojectapp.utils.apiReq
import baydhowi.finalprojectapp.utils.gsonReq
import baydhowi.finalprojectapp.utils.invisible
import baydhowi.finalprojectapp.utils.visible
import baydhowi.finalprojectapp.view.match.SearchMatchView
import kotlinx.android.synthetic.main.activity_search_match.*
import org.jetbrains.anko.sdk27.coroutines.onQueryTextListener
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.support.v4.onRefresh

class SearchMatchActivity : AppCompatActivity(), SearchMatchView {

    private lateinit var swipeRefresh       : SwipeRefreshLayout
    private lateinit var progressBar        : ProgressBar
    lateinit var searchView                 : SearchView
    private lateinit var recyclerView       : RecyclerView
    lateinit var presenter                  : SearchMatchPresenter
    private var matchItems                  : MutableList<MatchData> = mutableListOf()
    private var dataItems                   : MutableList<SearchMatchData> = mutableListOf()
    lateinit var adapter                    : SearchMatchAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_match)

        // hide action bar
        supportActionBar?.hide()

        // initialize object from layout
        initObjects()

        // initialize object event
        initListener()

        // initialize adapter
        initAdapter()

        // initialize default data
        initDefaultData()

        // initialize swipe refresh
        setRefreshEvent()
    }

    override fun showDlg() {
        progressBar.visible()
    }

    override fun hideDlg() {
        progressBar.invisible()
    }

    override fun showData(data: List<SearchMatchData>) {
        dataItems.clear()
        dataItems.addAll(data)
        adapter.notifyDataSetChanged()
        hideDlg()
    }

    private fun initObjects() {
        swipeRefresh = swipe_search_match_id
        progressBar = search_match_progress_id
        searchView = search_view_match_id
        recyclerView = search_match_rv_id

        presenter = SearchMatchPresenter(this, apiReq(), gsonReq())
    }

    private fun initAdapter() {
        adapter = SearchMatchAdapter(dataItems) {
            setDataList(it)
            goToDetailMatch()
        }
        setDataToRecyclerView()
    }

    private fun setDataList(data: SearchMatchData) {
        matchItems.clear()
        matchItems.add(MatchData(
            data.mIdEvent,
            data.mDateEvent,
            data.mHomeTeam,
            data.mHomeScore,
            "",
            data.mAwayTeam,
            data.mAwayScore,
            "",
            data.mTime))
    }

    private fun setDataToRecyclerView() {
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun goToDetailMatch() {
        this.startActivity<DetailMatchActivity>("match_data" to matchItems[0])
    }

    private fun initListener() {
        searchView.onActionViewExpanded()
        searchView.onQueryTextListener() {
            onQueryTextChange { it ->
                presenter.getData(it, "event", "e")
                true
            }
            hideDlg()
        }
    }

    private fun initDefaultData() {
        var team: String = ""
        presenter.getData(team, "event", "e")
        hideDlg()
    }

    private fun setRefreshEvent() {
        swipeRefresh.onRefresh {
            initDefaultData()
        }
    }
}
