package baydhowi.finalprojectapp.presenter.match

import baydhowi.finalprojectapp.api.ApiRequest
import baydhowi.finalprojectapp.api.TheSportDBApi
import baydhowi.finalprojectapp.model.response.BadgeResponse
import baydhowi.finalprojectapp.model.response.DetailMatchResponse
import baydhowi.finalprojectapp.utils.CoroutineContextProvider
import baydhowi.finalprojectapp.view.match.DetailMatchView
import com.google.gson.Gson
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class DetailMatchPresenter(public val v: DetailMatchView,
                           public val req: ApiRequest,
                           public val gson: Gson,
                           private val ctx: CoroutineContextProvider = CoroutineContextProvider())
{
    fun getTeamBadge(id: String?, type: String?, action: String?, teamType: String?){
        GlobalScope.launch(ctx.main){
            val dataTeam = gson.fromJson(req
                .doRequest(TheSportDBApi.getDataFromURL(id, type, action)).await(),
                BadgeResponse::class.java
            )

            // validasi saat result null tidak close apps
            if (dataTeam.teams != null) {
                if(teamType == "Away")
                    v.showAwayTeamBadge(dataTeam.teams)
                else
                    v.showHomeTeamBadge(dataTeam.teams)
            }
        }
    }

    fun getMatchDetail(id: String?, type: String?, action: String?){
        GlobalScope.launch(ctx.main){
            val dataDetail = gson.fromJson(req
                .doRequest(TheSportDBApi.getDataFromURL(id, type, action)).await(),
                DetailMatchResponse::class.java
            )

            // validasi saat result null tidak close apps
            if (dataDetail.events != null) { v.showData(dataDetail.events) }
        }
    }
}