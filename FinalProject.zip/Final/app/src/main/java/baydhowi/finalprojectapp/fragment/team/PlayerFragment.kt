package baydhowi.finalprojectapp.fragment.team


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.activity.team.DetailPlayerActivity
import baydhowi.finalprojectapp.adapter.team.PlayerAdapter
import baydhowi.finalprojectapp.model.data.PlayerData
import baydhowi.finalprojectapp.model.data.TeamData
import baydhowi.finalprojectapp.presenter.team.PlayerPresenter
import baydhowi.finalprojectapp.utils.apiReq
import baydhowi.finalprojectapp.utils.gsonReq
import baydhowi.finalprojectapp.utils.invisible
import baydhowi.finalprojectapp.utils.visible
import baydhowi.finalprojectapp.view.team.PlayerView
import kotlinx.android.synthetic.main.fragment_player.*
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.support.v4.onRefresh

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 *
 */
class PlayerFragment : Fragment(), PlayerView {

    private lateinit var teamData: TeamData
    lateinit var id: String
    private var dataItems: MutableList<PlayerData> = mutableListOf()
    lateinit var progressBar: ProgressBar
    lateinit var swipeRefresh: SwipeRefreshLayout
    lateinit var presenter: PlayerPresenter
    lateinit var adapter: PlayerAdapter
    lateinit var recyclerView: RecyclerView

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        // initialize intent
        initIntent()

        // initialize objects
        initObjects()

        // initialize recycler view
        initRecyclerView()

        // initialize default data
        initDefaultData()

        // initialize swipe refresh
        initSwipeRefresh()
    }

    private fun initIntent() {
        teamData = activity?.intent!!.getParcelableExtra("team_data")
        id = teamData.mIdTeam!!
    }

    private fun initRecyclerView() {
        adapter = PlayerAdapter(dataItems) {
            context?.startActivity<DetailPlayerActivity>("player_data" to it)
        }
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter
    }

    private fun initSwipeRefresh() {
        swipeRefresh.onRefresh {
            initDefaultData()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_player, container, false)
    }

    private fun initObjects() {
        progressBar = player_progress_id
        swipeRefresh = player_swipe_refresh_id
        recyclerView = player_rv_id

        presenter = PlayerPresenter(this, apiReq(), gsonReq())
    }

    private fun initDefaultData() {
        presenter.getData(id, "lookup_all_players", "id")
    }

    override fun showDlg() {
        progressBar.visible()
    }

    override fun hideDlg() {
        progressBar.invisible()
    }

    override fun showData(data: List<PlayerData>) {
        swipeRefresh.isRefreshing = false
        dataItems.clear()
        dataItems.addAll(data)
        adapter.notifyDataSetChanged()
        hideDlg()
    }
}
