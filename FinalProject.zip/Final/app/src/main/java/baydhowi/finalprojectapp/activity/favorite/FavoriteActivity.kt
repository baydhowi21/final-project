package baydhowi.finalprojectapp.activity.favorite

import android.os.Bundle
import android.support.v4.app.FragmentTransaction
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.fragment.favorite.FavoriteFragment

class FavoriteActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favorite)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Favorites"

        // initialize fragment page
        setFragmentToContainer()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item != null) {
            return when (item.itemId) {
                android.R.id.home -> {
                    super.onBackPressed()
                    true
                }
                else -> super.onOptionsItemSelected(item)
            }
        } else {
            return super.onOptionsItemSelected(item)
        }
    }

    fun setFragmentToContainer() {
        var ft: FragmentTransaction = supportFragmentManager.beginTransaction()
        ft.replace(R.id.fragment_favorite, FavoriteFragment())
        ft.commit()
    }

}
