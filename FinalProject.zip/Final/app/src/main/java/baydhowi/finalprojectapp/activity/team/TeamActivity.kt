package baydhowi.finalprojectapp.activity.team

import android.os.Bundle
import android.support.v4.app.FragmentTransaction
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.fragment.team.TeamFragment
import org.jetbrains.anko.startActivity

class TeamActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_team)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Teams"

        // initialize fragment page
        setFragmentToContainer()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.search_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item != null) {
            return when (item.itemId) {
                android.R.id.home -> {
                    super.onBackPressed()
                    true
                }
                R.id.search_menu_id -> {
                    startActivity<SearchTeamActivity>()
                    true
                }
                else -> super.onOptionsItemSelected(item)
            }
        } else {
            return super.onOptionsItemSelected(item)
        }
    }

    fun setFragmentToContainer() {
        var ft: FragmentTransaction = supportFragmentManager.beginTransaction()
        ft.replace(R.id.fragment_team, TeamFragment())
        ft.commit()
    }
}
