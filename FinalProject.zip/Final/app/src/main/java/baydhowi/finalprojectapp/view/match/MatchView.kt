package baydhowi.finalprojectapp.view.match

import baydhowi.finalprojectapp.model.data.MatchData

interface MatchView {

    fun showDlg()
    fun hideDlg()
    fun showData(data: List<MatchData>)

}