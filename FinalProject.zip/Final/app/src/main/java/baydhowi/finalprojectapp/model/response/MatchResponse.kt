package baydhowi.finalprojectapp.model.response

import baydhowi.finalprojectapp.model.data.MatchData

data class MatchResponse (val events: List<MatchData>)