package baydhowi.finalprojectapp.model.data

import com.google.gson.annotations.SerializedName

data class BadgeData (
    @SerializedName("strTeamBadge")
    val mTeamBadge: String? = ""
)