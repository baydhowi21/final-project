package baydhowi.finalprojectapp.view.team

import baydhowi.finalprojectapp.model.data.PlayerData

interface PlayerView {

    fun showDlg()
    fun hideDlg()
    fun showData(data: List<PlayerData>)

}