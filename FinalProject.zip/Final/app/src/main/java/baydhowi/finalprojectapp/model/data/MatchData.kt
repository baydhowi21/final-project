package baydhowi.finalprojectapp.model.data

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class MatchData (
    @SerializedName("idEvent")
    var mIdEvent: String? = null,

    @SerializedName("dateEvent")
    var mDateEvent: String? = null,

    @SerializedName("strHomeTeam")
    var mHomeTeam: String? = null,

    @SerializedName("intHomeScore")
    var mHomeScore: String? = null,

    @SerializedName("strHomeGoalDetails")
    val mHomeGoalDetails: String? = null,

    @SerializedName("strAwayTeam")
    var mAwayTeam: String? = null,

    @SerializedName("intAwayScore")
    var mAwayScore: String? = null,

    @SerializedName("strAwayGoalDetails")
    val mAwayGoalDetails: String? = null,

    @SerializedName("strTime")
    var mTime: String? = null
) : Parcelable