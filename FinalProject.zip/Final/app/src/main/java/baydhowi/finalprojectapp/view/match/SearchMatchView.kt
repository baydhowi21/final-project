package baydhowi.finalprojectapp.view.match

import baydhowi.finalprojectapp.model.data.SearchMatchData

interface SearchMatchView {

    fun showDlg()
    fun hideDlg()
    fun showData(data: List<SearchMatchData>)

}