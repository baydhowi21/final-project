package baydhowi.finalprojectapp.adapter.match

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.fragment.match.NextMatchFragment
import baydhowi.finalprojectapp.holder.match.NextMatchHolder
import baydhowi.finalprojectapp.model.data.MatchData
import baydhowi.finalprojectapp.presenter.match.MatchPresenter

class NextMatchAdapter(private val data: MutableList<MatchData>,
                       private val event: NextMatchFragment.OnFragmentInteractionListener?)
    : RecyclerView.Adapter<NextMatchHolder>()
{
    private lateinit var presenter          : MatchPresenter

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NextMatchHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.match_data, parent, false)
        return NextMatchHolder(v)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: NextMatchHolder, position: Int) {
        holder.bindItem(data[position], event)
    }
}