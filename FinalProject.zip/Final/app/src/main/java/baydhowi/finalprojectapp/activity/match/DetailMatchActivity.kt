package baydhowi.finalprojectapp.activity.match

import android.database.sqlite.SQLiteConstraintException
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.R.menu.fav_menu
import baydhowi.finalprojectapp.db.dbApp
import baydhowi.finalprojectapp.db.table.MatchTable
import baydhowi.finalprojectapp.model.data.BadgeData
import baydhowi.finalprojectapp.model.data.DetailMatchData
import baydhowi.finalprojectapp.model.data.MatchData
import baydhowi.finalprojectapp.presenter.match.DetailMatchPresenter
import baydhowi.finalprojectapp.utils.*
import baydhowi.finalprojectapp.view.match.DetailMatchView
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_detail_match.*
import org.jetbrains.anko.db.classParser
import org.jetbrains.anko.db.delete
import org.jetbrains.anko.db.insert
import org.jetbrains.anko.db.select
import java.text.SimpleDateFormat

class DetailMatchActivity : AppCompatActivity(), DetailMatchView {

    lateinit var match_data: MatchData
    private var menuItem: Menu? = null
    private var isActive: Boolean = false
    private lateinit var presenter: DetailMatchPresenter
    private lateinit var progress: ProgressBar
    lateinit var main_scroll: ScrollView

    private lateinit var id_event : String
    var date_event: String? = null
    var home_team: String? = null
    var home_score: String? = null
    var away_team: String? = null
    var away_score: String? = null
    var match_time : String? = null

    lateinit var home_image: ImageView
    lateinit var away_image: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_match)

        initObjects()

        val intent = intent
        if (intent.hasExtra("match_data")) {
            match_data = intent.getParcelableExtra("match_data")
            initDataFromParcelable()
        } else {
            initDataFromStringExtras()
        }

        initHeaderData()
        initDetailData()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = home_team + " vs " + away_team
    }

    private fun initObjects() {
        progress = detail_progress_id
        home_image = home_image_id
        away_image = away_image_id
        main_scroll = main_scroll_id
    }

    private fun initDetailData() {
        showDlg()
        defaultFav()
        initPresenter()
        hideDlg()
    }

    private fun initDataFromParcelable() {
        id_event = match_data.mIdEvent!!
        date_event = match_data.mDateEvent
        home_team = match_data.mHomeTeam
        home_score = match_data.mHomeScore
        away_team = match_data.mAwayTeam
        away_score = match_data.mAwayScore
        match_time = match_data.mTime
    }

    private fun initDataFromStringExtras() {
        id_event = intent.getStringExtra("id_event")
        date_event = intent.getStringExtra("date_event")
        home_team = intent.getStringExtra("home_team")
        home_score = intent.getStringExtra("home_score")
        away_team = intent.getStringExtra("away_team")
        away_score = intent.getStringExtra("away_score")
        match_time = intent.getStringExtra("match_time")
    }

    private fun initHeaderData() {
        val dateConvert = convertToGMT(date_event, validateNullTime(match_time))
        val newDate = SimpleDateFormat("E, d MMM yyyy")
        val newTime = SimpleDateFormat("HH:mm")
        val date = newDate.format(dateConvert)
        val time = newTime.format(dateConvert)

        date_detail_id.text = "$date"
        time_detail_id.text = "$time"
        home_detail_id.text = home_team
        home_score_id.text = home_score
        away_detail_id.text = away_team
        away_score_id.text = away_score
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(fav_menu, menu)
        menuItem = menu
        setMenu(this, isActive, menuItem)

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item != null) {
            return when (item.itemId) {
                android.R.id.home -> {
                    super.onBackPressed()
                    true
                }
                R.id.add_to_favorite_id -> {
                    if (isActive) {
                        remFav()
                    } else {
                        addFav()
                    }
                    isActive = !isActive
                    setMenu(this, isActive, menuItem)
                    true
                }
                else -> super.onOptionsItemSelected(item)
            }
        } else {
            return super.onOptionsItemSelected(item)
        }
    }

    private fun initPresenter() {
        presenter = DetailMatchPresenter(this, apiReq(), gsonReq())
        presenter.getMatchDetail(id_event, "detail", "id")
        presenter.getTeamBadge(home_team, "badge", "t", "Home")
        presenter.getTeamBadge(away_team, "badge", "t","Away")
    }

    private fun defaultFav(){
        try {
            dbApp.use {
                val result = select(MatchTable.table_name).whereArgs("( id_event = {id_event})",
                    "id_event" to id_event)
                val favoriteMatch = result.parseList(classParser<MatchTable>())
                if (!favoriteMatch.isEmpty()) isActive = true
            }
        } catch (e: SQLiteConstraintException){
            Log.d("BTW - DEF", e.localizedMessage)
        }
    }

    private fun addFav() {
        try {
            dbApp.use {
                insert(MatchTable.table_name,
                    MatchTable.id_event to id_event,
                    MatchTable.date_event to date_event,
                    MatchTable.home_team to home_team,
                    MatchTable.away_team to away_team,
                    MatchTable.home_score to home_score,
                    MatchTable.away_score to away_score,
                    MatchTable.match_time to match_time)
            }
            Snackbar.make(main_scroll,
                "Data " + home_team + " vs " + away_team + " telah ditambahkan ke favorit",
                Snackbar.LENGTH_SHORT).show()
        } catch (e: SQLiteConstraintException){
            Log.d("BTW - ADD", e.localizedMessage)
        }
    }

    private fun remFav() {
        try {
            dbApp.use {
                delete(MatchTable.table_name, "( id_event = {id_event} )",
                    "id_event" to id_event)
            }
            Snackbar.make(main_scroll,
                "Data " + home_team + " vs " + away_team + " telah dihapus dari favorit",
                Snackbar.LENGTH_SHORT).show()
        } catch (e: SQLiteConstraintException){
            Log.d("BTW - REM", e.localizedMessage)
        }
    }

    fun setDataToDisplay(listData: List<String> , tv: TextView) {
        for (value in listData) {
            tv.text = getDataStr(tv.text.toString(), value.trim())
        }
    }

    fun getDataStr(dataText: String?, value: String) : String? {
        var result: String?

        if (value != "null") {
            result = getString(R.string.description, dataText, value)
        } else {
            result = getString(R.string.description, "", " - ")
        }

        return result
    }

    override fun showDlg() {
        progress.visible()
    }

    override fun hideDlg() {
        progress.invisible()
    }

    override fun showData(data: List<DetailMatchData>) {
        initHomeTeamData(data)
        initAwayTeamData(data)
    }

    private fun initHomeTeamData(data: List<DetailMatchData>) {
        // HOME TEAM BEGIN
        val homeFormation   = splitData(data[0].mHomeFormation.toString().trim())
        val homeGoals       = splitData(data[0].mHomeGoalDetails)
        val homeShots       = splitData(data[0].mHomeShots)
        val homeGK          = splitData(data[0].mHomeLineupGoalkeeper)
        val homeDef         = splitData(data[0].mHomeLineupDefense)
        val homeMid         = splitData(data[0].mHomeLineupMid)
        val homeFor         = splitData(data[0].mHomeLineupForward)
        val homeSub         = splitData(data[0].mHomeLineupSubstitutes)

        setDataToDisplay(homeFormation, home_formation_id)
        setDataToDisplay(homeGoals, home_goal_id)
        setDataToDisplay(homeShots, home_shot_id)
        setDataToDisplay(homeGK, home_gk_id)
        setDataToDisplay(homeDef, home_def_id)
        setDataToDisplay(homeMid, home_mid_id)
        setDataToDisplay(homeFor, home_for_id)
        setDataToDisplay(homeSub, home_sub_id)
        // HOME TEAM END
    }

    private fun initAwayTeamData(data: List<DetailMatchData>) {
        // AWAY TEAM BEGIN
        val awayFormation   = splitData(data[0].mAwayFormation.toString().trim())
        val awayGoals       = splitData(data[0].mAwayGoalDetails)
        val awayShots       = splitData(data[0].mAwayShots)
        val awayGK          = splitData(data[0].mAwayLineupGoalkeeper)
        val awayDef         = splitData(data[0].mAwayLineupDefense)
        val awayMid         = splitData(data[0].mAwayLineupMid)
        val awayFor         = splitData(data[0].mAwayLineupForward)
        val awaySub         = splitData(data[0].mAwayLineupSubstitutes)

        setDataToDisplay(awayFormation, away_formation_id)
        setDataToDisplay(awayGoals, away_goal_id)
        setDataToDisplay(awayShots, away_shot_id)
        setDataToDisplay(awayGK, away_gk_id)
        setDataToDisplay(awayDef, away_def_id)
        setDataToDisplay(awayMid, away_mid_id)
        setDataToDisplay(awayFor, away_for_id)
        setDataToDisplay(awaySub, away_sub_id)
        // AWAY TEAM END
    }

    override fun showHomeTeamBadge(data: List<BadgeData>) {
        Glide.with(this).load(data[0].mTeamBadge).into(home_image)
    }

    override fun showAwayTeamBadge(data: List<BadgeData>) {
        Glide.with(this).load(data[0].mTeamBadge).into(away_image)
    }
}
