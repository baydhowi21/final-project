package baydhowi.finalprojectapp.activity

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.CardView
import android.view.View
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.activity.favorite.FavoriteActivity
import baydhowi.finalprojectapp.activity.match.MatchActivity
import baydhowi.finalprojectapp.activity.team.TeamActivity
import com.facebook.stetho.Stetho
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.startActivity

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var match_card: CardView
    private lateinit var team_card: CardView
    private lateinit var fav_card: CardView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // hide action bar
        supportActionBar?.hide()

        // init db viewer
        Stetho.initializeWithDefaults(this)

        // initialize object dari layout
        initObjects()

        // initialize event
        initListeners()

    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.match_id -> {
                startActivity<MatchActivity>()
            }
            R.id.team_id -> {
                startActivity<TeamActivity>()
            }
            R.id.favorite_id -> {
                startActivity<FavoriteActivity>()
            }
        }
    }

    private fun initObjects() {
        match_card = match_id
        team_card = team_id
        fav_card = favorite_id
    }

    private fun initListeners() {
        match_card.setOnClickListener( this )
        team_card.setOnClickListener( this )
        fav_card.setOnClickListener( this )
    }
}
