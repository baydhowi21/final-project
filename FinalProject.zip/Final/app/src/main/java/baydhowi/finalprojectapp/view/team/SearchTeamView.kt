package baydhowi.finalprojectapp.view.team

import baydhowi.finalprojectapp.model.data.TeamData

interface SearchTeamView {

    fun showDlg()
    fun hideDlg()
    fun showData(data: List<TeamData>)

}