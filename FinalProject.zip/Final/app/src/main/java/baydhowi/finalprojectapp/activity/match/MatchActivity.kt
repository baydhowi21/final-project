package baydhowi.finalprojectapp.activity.match

import android.os.Bundle
import android.support.v4.app.FragmentTransaction
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.fragment.match.MatchFragment
import baydhowi.finalprojectapp.fragment.match.NextMatchFragment
import baydhowi.finalprojectapp.fragment.match.PrevMatchFragment
import baydhowi.finalprojectapp.model.data.MatchData
import org.jetbrains.anko.startActivity

class MatchActivity : AppCompatActivity(),
    PrevMatchFragment.OnFragmentInteractionListener,
    NextMatchFragment.OnFragmentInteractionListener
{

    override fun onFragmentInteraction(item: MatchData) {
        startActivity<DetailMatchActivity>("match_data" to item)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_match)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Matches"

        // initialize fragment page
        setFragmentToContainer()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.search_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item != null) {
            return when (item.itemId) {
                android.R.id.home -> {
                    super.onBackPressed()
                    true
                }
                R.id.search_menu_id -> {
                    startActivity<SearchMatchActivity>()
                    true
                }
                else -> super.onOptionsItemSelected(item)
            }
        } else {
            return super.onOptionsItemSelected(item)
        }
    }

    fun setFragmentToContainer() {
        var ft: FragmentTransaction = supportFragmentManager.beginTransaction()
        ft.replace(R.id.fragment_match, MatchFragment())
        ft.commit()
    }

}
