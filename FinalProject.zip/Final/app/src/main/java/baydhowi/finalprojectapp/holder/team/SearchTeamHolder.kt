package baydhowi.finalprojectapp.holder.team

import android.support.v7.widget.RecyclerView
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import baydhowi.finalprojectapp.model.data.TeamData
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.team_data.view.*

class SearchTeamHolder(v: View): RecyclerView.ViewHolder(v)
{
    val team_image: ImageView = v.team_image_id
    val team_name: TextView = v.team_name_id
    val team_stadium: TextView = v.team_stadium_id

    fun bindItem(item: TeamData, listener: (TeamData) -> Unit) {
        team_name.text = item.mTeamName
        Glide.with(itemView.context).load(item.mTeamBadge).into(team_image)
        team_stadium.text = item.mTeamStadium

        itemView.setOnClickListener {
            listener(item)
        }
    }
}