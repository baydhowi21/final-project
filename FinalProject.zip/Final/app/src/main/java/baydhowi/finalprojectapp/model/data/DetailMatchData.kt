package baydhowi.finalprojectapp.model.data

import com.google.gson.annotations.SerializedName

data class DetailMatchData (
    @SerializedName("idEvent")
    val idEvent: String? = null,

    @SerializedName("strEvent")
    val strEvent: String? = null,

    @SerializedName("idLeague")
    val idLeague: String? = null,

    @SerializedName("dateEvent")
    val dateEvent: String? = null,

    @SerializedName("strDate")
    val strDate: String? = null,

    @SerializedName("strSport")
    val strSport: String? = null,

    @SerializedName("strCountry")
    val strCountry: Any? = null,

    @SerializedName("idSoccerXML")
    val idSoccerXML: String? = null,

    @SerializedName("strTVStation")
    val strTVStation: Any? = null,

    @SerializedName("strThumb")
    val strThumb: Any? = null,

    @SerializedName("strLeague")
    val strLeague: String? = null,

    @SerializedName("strCity")
    val strCity: Any? = null,

    @SerializedName("strPoster")
    val strPoster: Any? = null,

    @SerializedName("intRound")
    val intRound: String? = null,

    @SerializedName("strMap")
    val strMap: Any? = null,

    @SerializedName("strBanner")
    val strBanner: Any? = null,

    @SerializedName("strFanart")
    val strFanart: Any? = null,

    @SerializedName("strDescriptionEN")
    val strDescriptionEN: Any? = null,

    @SerializedName("strResult")
    val strResult: Any? = null,

    @SerializedName("strCircuit")
    val strCircuit: Any? = null,

    @SerializedName("strFilename")
    val strFilename: String? = null,

    @SerializedName("strTime")
    val strTime: String? = null,

    @SerializedName("strLocked")
    val strLocked: String? = null,

    // anjir pake window bingung wkwkwkw

    @SerializedName("strSeason")
    val strSeason: String? = null,

    @SerializedName("intSpectators")
    val intSpectators: Any? = null,

    // HOME TEAM
    @SerializedName("idHomeTeam")
    val mIdHomeTeam: String? = null,

    @SerializedName("strHomeTeam")
    val mHomeTeam: String? = null,

    @SerializedName("strHomeFormation")
    val mHomeFormation: String? = null,

    @SerializedName("intHomeScore")
    val mHomeScore: String? = null,

    @SerializedName("strHomeGoalDetails")
    val mHomeGoalDetails: String? = null,

    @SerializedName("intHomeShots")
    val mHomeShots: String? = null,

    // HOME LINE UP
    @SerializedName("strHomeLineupGoalkeeper")
    val mHomeLineupGoalkeeper: String? = null,

    @SerializedName("strHomeLineupDefense")
    val mHomeLineupDefense: String? = null,

    @SerializedName("strHomeLineupMidfield")
    val mHomeLineupMid: String? = null,

    @SerializedName("strHomeLineupForward")
    val mHomeLineupForward: String? = null,

    @SerializedName("strHomeLineupSubstitutes")
    val mHomeLineupSubstitutes: String? = null,

    @SerializedName("strHomeYellowCards")
    val mHomeYellowCards: String? = null,

    @SerializedName("strHomeRedCards")
    val mHomeRedCards: String? = null,

    // AWAY TEAM
    @SerializedName("idAwayTeam")
    val mIdAwayTeam: String? = null,

    @SerializedName("strAwayTeam")
    val mAwayTeam: String? = null,

    @SerializedName("strAwayFormation")
    val mAwayFormation: String? = null,

    @SerializedName("intAwayScore")
    val mAwayScore: String? = null,

    @SerializedName("strAwayGoalDetails")
    val mAwayGoalDetails: String? = null,

    @SerializedName("intAwayShots")
    val mAwayShots: String? = null,

    // AWAY LINE UP
    @SerializedName("strAwayLineupGoalkeeper")
    val mAwayLineupGoalkeeper: String? = null,

    @SerializedName("strAwayLineupDefense")
    val mAwayLineupDefense: String? = null,

    @SerializedName("strAwayLineupMidfield")
    val mAwayLineupMid: String? = null,

    @SerializedName("strAwayLineupForward")
    val mAwayLineupForward: String? = null,

    @SerializedName("strAwayLineupSubstitutes")
    val mAwayLineupSubstitutes: String? = null,

    @SerializedName("strAwayYellowCards")
    val mAwayYellowCards: String? = null,

    @SerializedName("strAwayRedCards")
    val mAwayRedCards: String? = null
)