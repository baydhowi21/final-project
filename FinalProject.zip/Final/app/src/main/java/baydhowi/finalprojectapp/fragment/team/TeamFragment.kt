package baydhowi.finalprojectapp.fragment.team


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ProgressBar
import android.widget.Spinner
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.activity.team.DetailTeamActivity
import baydhowi.finalprojectapp.adapter.team.TeamAdapter
import baydhowi.finalprojectapp.model.data.TeamData
import baydhowi.finalprojectapp.presenter.team.TeamPresenter
import baydhowi.finalprojectapp.utils.apiReq
import baydhowi.finalprojectapp.utils.gsonReq
import baydhowi.finalprojectapp.utils.invisible
import baydhowi.finalprojectapp.utils.visible
import baydhowi.finalprojectapp.view.team.TeamView
import kotlinx.android.synthetic.main.fragment_team.*
import org.jetbrains.anko.startActivity

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 *
 */
class TeamFragment : Fragment(), TeamView {

    private var dataItems               : MutableList<TeamData> = mutableListOf()
    private lateinit var presenter      : TeamPresenter
    private lateinit var adapter        : TeamAdapter

    private lateinit var recyclerView   : RecyclerView
    private lateinit var progressBar    : ProgressBar
    private lateinit var swipeRefresh   : SwipeRefreshLayout
    private lateinit var spinner        : Spinner
    private lateinit var league         : String

    override fun showDlg() {
        progressBar.visible()
    }

    override fun hideDlg() {
        progressBar.invisible()
    }

    override fun showData(data: List<TeamData>) {
        swipeRefresh.isRefreshing = false
        dataItems.clear()
        dataItems.addAll(data)
        adapter.notifyDataSetChanged()
        hideDlg()
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        // initialize object from layout
        initObjects()

        // initialize spinner data
        initSpinnerData()

        // initialize object event
        initListener()

        // initialize default data
        initDefaultData()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_team, container, false)
    }

    private fun initObjects() {
        progressBar = team_progress_id
        swipeRefresh = team_swipe_refresh_id
        spinner = spinner_team_id
        recyclerView = team_rv_id

        presenter = TeamPresenter(this, apiReq(), gsonReq())
    }

    private fun initSpinnerData() {
        val spinnerAdapter = ArrayAdapter(context,
            android.R.layout.simple_spinner_dropdown_item,
            resources.getStringArray(R.array.league))
        spinner.adapter = spinnerAdapter
    }

    private fun initListener() {
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {
                //  TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                initDefaultData()
            }
        }

        initRecyclerView()
    }

    private fun initRecyclerView() {
        adapter = TeamAdapter(dataItems) {
            context?.startActivity<DetailTeamActivity>("team_data" to it)
        }
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter
    }

    private fun initDefaultData() {
        league = spinner.selectedItem.toString()
        presenter.getData(league, "all_teams", "l")
    }
}
