package baydhowi.finalprojectapp.presenter.team

import baydhowi.finalprojectapp.api.ApiRequest
import baydhowi.finalprojectapp.api.TheSportDBApi
import baydhowi.finalprojectapp.model.response.TeamResponse
import baydhowi.finalprojectapp.utils.CoroutineContextProvider
import baydhowi.finalprojectapp.view.team.TeamView
import com.google.gson.Gson
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class TeamPresenter(private val v: TeamView,
                    private val req: ApiRequest,
                    private val gson: Gson,
                    private val ctx: CoroutineContextProvider = CoroutineContextProvider())
{
    fun getData(id: String?, type: String?, action: String?) {
        GlobalScope.launch(ctx.main) {
            val data = gson.fromJson(req
                .doRequest(TheSportDBApi.getDataFromURL(id, type, action)).await(),
                TeamResponse::class.java
            )

            // validasi saat result null tidak close apps
            if (data.teams != null) {
                v.showData(data.teams)
            }

            v.hideDlg()
        }
    }
}