package baydhowi.finalprojectapp.adapter.team

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import baydhowi.finalprojectapp.R
import baydhowi.finalprojectapp.holder.team.TeamHolder
import baydhowi.finalprojectapp.model.data.TeamData

class TeamAdapter(private val data: MutableList<TeamData>,
                  private val event: (TeamData) -> Unit)
    : RecyclerView.Adapter<TeamHolder>()
{
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TeamHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.team_data, parent, false)
        return TeamHolder(v)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: TeamHolder, position: Int) {
        holder.bindItem(data[position], event)
    }
}