package baydhowi.finalprojectapp.presenter.match

import baydhowi.finalprojectapp.api.ApiRequest
import baydhowi.finalprojectapp.api.TheSportDBApi
import baydhowi.finalprojectapp.model.response.SearchMatchResponse
import baydhowi.finalprojectapp.utils.CoroutineContextProvider
import baydhowi.finalprojectapp.view.match.SearchMatchView
import com.google.gson.Gson
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class SearchMatchPresenter(private val v: SearchMatchView,
                           private val req: ApiRequest,
                           private val gson: Gson,
                           private val ctx: CoroutineContextProvider = CoroutineContextProvider())
{
    fun getData(id: String?, type: String?, action: String?) {
        GlobalScope.launch(ctx.main){
            val match = gson.fromJson(req
                .doRequest(TheSportDBApi.getDataFromURL(id, type, action)).await(),
                SearchMatchResponse::class.java
            )

            // validasi saat result null tidak close apps
            if (match.event != null) { v.showData(match.event) }

            v.hideDlg()
        }
    }
}