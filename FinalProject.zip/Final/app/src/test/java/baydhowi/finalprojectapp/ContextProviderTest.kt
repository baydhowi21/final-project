package baydhowi.finalprojectapp

import baydhowi.finalprojectapp.utils.CoroutineContextProvider
import kotlinx.coroutines.Dispatchers.Unconfined
import kotlin.coroutines.CoroutineContext

class ContextProviderTest : CoroutineContextProvider(){
    override val main: CoroutineContext = Unconfined
}