package baydhowi.finalprojectapp.presenter.match

import baydhowi.finalprojectapp.ContextProviderTest
import baydhowi.finalprojectapp.api.ApiRequest
import baydhowi.finalprojectapp.api.TheSportDBApi
import baydhowi.finalprojectapp.model.data.SearchMatchData
import baydhowi.finalprojectapp.model.response.SearchMatchResponse
import baydhowi.finalprojectapp.view.match.SearchMatchView
import com.google.gson.Gson
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations

class SearchMatchPresenterTest {

    @Mock
    private lateinit var v: SearchMatchView
    @Mock
    private lateinit var gson: Gson
    @Mock
    private lateinit var api: ApiRequest

    private lateinit var presenter: SearchMatchPresenter

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        presenter = SearchMatchPresenter(v, api, gson, ContextProviderTest())
    }

    @Test
    fun getData() {
        val data: MutableList<SearchMatchData> = mutableListOf()
        val response = SearchMatchResponse(data)
        val id = "Arsenal_vs_Chelsea"
        val type = "event"
        val action = "e"

        GlobalScope.launch {
            Mockito.`when`(gson.fromJson(api
                .doRequest(TheSportDBApi.getDataFromURL(id, type, action)).await(),
                SearchMatchResponse::class.java
            )).thenReturn(response)

            presenter.getData(id, type, action)

            Mockito.verify(v).showData(data)
        }
    }
}