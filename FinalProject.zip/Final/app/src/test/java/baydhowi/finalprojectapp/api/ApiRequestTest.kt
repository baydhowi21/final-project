package baydhowi.finalprojectapp.api

import org.junit.Test
import org.mockito.Mockito

class ApiRequestTest {

    @Test
    fun doRequest() {
        val apiRequest = Mockito.mock(ApiRequest::class.java)
        val url = "https://www.thesportsdb.com/api/v1/json/1/search_all_teams.php?l=English%20Premier%20League\""
        apiRequest.doRequest(url)
        Mockito.verify(apiRequest).doRequest(url)
    }
}