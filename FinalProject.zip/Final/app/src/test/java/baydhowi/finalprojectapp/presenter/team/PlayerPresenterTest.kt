package baydhowi.finalprojectapp.presenter.team

import baydhowi.finalprojectapp.ContextProviderTest
import baydhowi.finalprojectapp.api.ApiRequest
import baydhowi.finalprojectapp.api.TheSportDBApi
import baydhowi.finalprojectapp.model.data.PlayerData
import baydhowi.finalprojectapp.model.response.PlayerResponse
import baydhowi.finalprojectapp.view.team.PlayerView
import com.google.gson.Gson
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations

class PlayerPresenterTest {

    @Mock
    private lateinit var v: PlayerView
    @Mock
    private lateinit var gson: Gson
    @Mock
    private lateinit var api: ApiRequest

    private lateinit var presenter: PlayerPresenter

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        presenter = PlayerPresenter(v, api, gson, ContextProviderTest())
    }

    @Test
    fun getData() {
        val data: MutableList<PlayerData> = mutableListOf()
        val response = PlayerResponse(data)
        val id = "133604"
        val type = "lookup_all_players"
        val action = "id"

        GlobalScope.launch {
            Mockito.`when`(gson.fromJson(api
                .doRequest(TheSportDBApi.getDataFromURL(id, type, action)).await(),
                PlayerResponse::class.java
            )).thenReturn(response)

            presenter.getData(id, type, action)

            Mockito.verify(v).showData(data)
        }
    }
}