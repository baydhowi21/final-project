package baydhowi.finalprojectapp.presenter.match

import baydhowi.finalprojectapp.ContextProviderTest
import baydhowi.finalprojectapp.api.ApiRequest
import baydhowi.finalprojectapp.api.TheSportDBApi
import baydhowi.finalprojectapp.model.data.BadgeData
import baydhowi.finalprojectapp.model.data.DetailMatchData
import baydhowi.finalprojectapp.model.response.BadgeResponse
import baydhowi.finalprojectapp.model.response.DetailMatchResponse
import baydhowi.finalprojectapp.view.match.DetailMatchView
import com.google.gson.Gson
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations

class DetailMatchPresenterTest {

    @Mock
    private lateinit var v: DetailMatchView
    @Mock
    private lateinit var gson: Gson
    @Mock
    private lateinit var api: ApiRequest

    private lateinit var presenter: DetailMatchPresenter

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        presenter = DetailMatchPresenter(v, api, gson, ContextProviderTest())
    }

    @Test
    fun getTeamBadge() {
        val data: MutableList<BadgeData> = mutableListOf()
        val response = BadgeResponse(data)
        val id = "Arsenal"
        val type = "badge"
        val action = "t"
        val teamType = "Away"

        GlobalScope.launch {
            Mockito.`when`(gson.fromJson(api
                .doRequest(TheSportDBApi.getDataFromURL(id, type, action)).await(),
                BadgeResponse::class.java
            )).thenReturn(response)

            presenter.getTeamBadge(id, type, action, teamType)

            Mockito.verify(v).showAwayTeamBadge(data)
        }
    }

    @Test
    fun getMatchDetail() {
        val data: MutableList<DetailMatchData> = mutableListOf()
        val response = DetailMatchResponse(data)
        val id = "441613"
        val type = "detail"
        val action = "id"

        GlobalScope.launch {
            Mockito.`when`(gson.fromJson(api
                .doRequest(TheSportDBApi.getDataFromURL(id, type, action)).await(),
                DetailMatchResponse::class.java
            )).thenReturn(response)

            presenter.getMatchDetail(id, type, action)

            Mockito.verify(v).showData(data)
        }
    }
}