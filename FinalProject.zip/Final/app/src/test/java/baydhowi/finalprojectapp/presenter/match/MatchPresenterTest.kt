package baydhowi.finalprojectapp.presenter.match

import baydhowi.finalprojectapp.ContextProviderTest
import baydhowi.finalprojectapp.api.ApiRequest
import baydhowi.finalprojectapp.api.TheSportDBApi
import baydhowi.finalprojectapp.model.data.MatchData
import baydhowi.finalprojectapp.model.response.MatchResponse
import baydhowi.finalprojectapp.view.match.MatchView
import com.google.gson.Gson
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations

class MatchPresenterTest {

    @Mock
    private lateinit var v: MatchView
    @Mock
    private lateinit var gson: Gson
    @Mock
    private lateinit var api: ApiRequest

    private lateinit var presenter: MatchPresenter

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        presenter = MatchPresenter(v, api, gson, ContextProviderTest())
    }

    @Test
    fun getData() {
        val data: MutableList<MatchData> = mutableListOf()
        val response = MatchResponse(data)
        val id = "4335"
        val type = "prev"
        val action = "id"

        GlobalScope.launch {
            Mockito.`when`(gson.fromJson(api
                .doRequest(TheSportDBApi.getDataFromURL(id, type, action)).await(),
                MatchResponse::class.java
            )).thenReturn(response)

            presenter.getData(id, type, action)

            Mockito.verify(v).showData(data)
        }
    }
}