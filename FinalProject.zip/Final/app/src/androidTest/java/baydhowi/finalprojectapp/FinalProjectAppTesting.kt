package baydhowi.finalprojectapp

import android.support.test.espresso.Espresso
import android.support.test.espresso.action.ViewActions
import android.support.test.espresso.assertion.ViewAssertions
import android.support.test.espresso.contrib.RecyclerViewActions
import android.support.test.espresso.matcher.ViewMatchers
import android.support.test.rule.ActivityTestRule
import android.support.test.runner.AndroidJUnit4
import android.support.v7.widget.RecyclerView
import baydhowi.finalprojectapp.activity.MainActivity
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class FinalProjectAppTesting {
    @Rule
    @JvmField var appTestRule = ActivityTestRule(MainActivity::class.java)

    @Test
    fun testingAppBehaviour(){
        Thread.sleep(3000)

        Espresso.onView(ViewMatchers.withId(R.id.match_id)).check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
        Espresso.onView(ViewMatchers.withId(R.id.match_id)).perform(ViewActions.click())

        Thread.sleep(3000)

        Espresso.onView(ViewMatchers.withId(R.id.next_rv_id)).check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
        Espresso.onView(ViewMatchers.withId(R.id.next_rv_id)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(7))
        Espresso.onView(ViewMatchers.withId(R.id.next_rv_id)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(7, ViewActions.click()))

        Thread.sleep(3000)

        Espresso.onView(ViewMatchers.withId(R.id.add_to_favorite_id)).check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
        Espresso.onView(ViewMatchers.withId(R.id.add_to_favorite_id)).perform(ViewActions.click())

        Thread.sleep(3000)

        Espresso.pressBack()
        Espresso.pressBack()

        Thread.sleep(3000)

        Espresso.onView(ViewMatchers.withId(R.id.team_id)).check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
        Espresso.onView(ViewMatchers.withId(R.id.team_id)).perform(ViewActions.click())

        Thread.sleep(3000)

        Espresso.onView(ViewMatchers.withId(R.id.team_rv_id)).check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
        Espresso.onView(ViewMatchers.withId(R.id.team_rv_id)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(7))
        Espresso.onView(ViewMatchers.withId(R.id.team_rv_id)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(7, ViewActions.click()))

        Thread.sleep(3000)

        Espresso.onView(ViewMatchers.withId(R.id.add_to_favorite_id)).check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
        Espresso.onView(ViewMatchers.withId(R.id.add_to_favorite_id)).perform(ViewActions.click())

        Thread.sleep(3000)

        Espresso.pressBack()
        Espresso.pressBack()

        Thread.sleep(3000)

        Espresso.onView(ViewMatchers.withId(R.id.favorite_id)).check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
        Espresso.onView(ViewMatchers.withId(R.id.favorite_id)).perform(ViewActions.click())

        Thread.sleep(3000)

        Espresso.pressBack()

        Thread.sleep(3000)
    }
}